# -*- coding: utf-8 -*-
"""Turn a simple live HLS MPEG-TS feed into local continuous MPEG-TS."""

import re
import threading
import time

try:
    import BaseHTTPServer as http_server
    import SocketServer as socket_server
    import urllib2 as url_request
    from urlparse import urljoin, urlsplit
except ImportError:
    import http.server as http_server
    import socketserver as socket_server
    import urllib.request as url_request
    from urllib.parse import urljoin, urlsplit


MAX_PLAYLIST = 128 * 1024
MAX_SEGMENT = 4 * 1024 * 1024


def parse_media_playlist(body, base_url):
    if not isinstance(body, str):
        body = body.decode('utf-8', 'replace')
    lines = [line.strip() for line in body.splitlines()]
    if not lines or lines[0] != '#EXTM3U':
        raise ValueError('Playlist HLS invalida')
    if any(line.startswith(('#EXT-X-KEY:', '#EXT-X-MAP:')) for line in lines):
        raise ValueError('HLS criptografado ou fMP4 nao suportado')
    marker = [line for line in lines if line.startswith('#EXT-X-MEDIA-SEQUENCE:')]
    if not marker:
        raise ValueError('Sequencia HLS ausente')
    first = int(marker[0].split(':', 1)[1])
    segments = []
    for line in lines:
        if not line or line.startswith('#'):
            continue
        address = urljoin(base_url, line)
        if urlsplit(address).path.lower().endswith('.ts'):
            segments.append((first + len(segments), address))
        else:
            raise ValueError('Segmento HLS nao e MPEG-TS')
    return segments


class HlsSequence(object):
    def __init__(self, media_url):
        self.media_url = media_url
        self.next_number = None

    def accept(self, body):
        segments = parse_media_playlist(body, self.media_url)
        fresh = [item for item in segments
                 if self.next_number is None or item[0] >= self.next_number]
        if fresh:
            self.next_number = fresh[-1][0] + 1
        return fresh


def _fetch(url, limit):
    response = url_request.urlopen(url, timeout=12)
    try:
        data = response.read(limit + 1)
    finally:
        response.close()
    if len(data) > limit:
        raise ValueError('Dados HLS grandes demais')
    return data


class _ThreadingServer(socket_server.ThreadingMixIn, http_server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class _Handler(http_server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def do_HEAD(self):
        self._headers()

    def _headers(self):
        if self.path != '/live.ts':
            self.send_error(404)
            return False
        self.send_response(200)
        self.send_header('Content-Type', 'video/MP2T')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        return True

    def do_GET(self):
        if not self._headers():
            return
        sequence = HlsSequence(self.server.media_url)
        failures = 0
        while not self.server.stop_event.is_set():
            try:
                body = _fetch(self.server.media_url, MAX_PLAYLIST)
                fresh = sequence.accept(body)
                for _, segment_url in fresh:
                    data = _fetch(segment_url, MAX_SEGMENT)
                    self.wfile.write(data)
                    self.wfile.flush()
                failures = 0
            except Exception as error:
                self.server.report('HLS: %s' % error)
                failures += 1
                if failures >= 4:
                    break
            self.server.stop_event.wait(0.8)


class HlsBridge(object):
    def __init__(self, media_url, report):
        self.server = _ThreadingServer(('127.0.0.1', 0), _Handler)
        self.server.media_url = media_url
        self.server.report = report
        self.server.stop_event = threading.Event()
        self.thread = None

    def start(self):
        self.thread = threading.Thread(target=self.server.serve_forever)
        self.thread.daemon = True
        self.thread.start()
        return 'http://127.0.0.1:%d/live.ts' % self.server.server_port

    def stop(self):
        self.server.stop_event.set()
        self.server.shutdown()
        self.server.server_close()
